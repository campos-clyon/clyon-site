import type { NextConfig } from "next";
const nextConfig: NextConfig = {
  output: "standalone",
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "**",
      },
    ],
  },
  compress: true,
  // Desabilitar completamente a geração de páginas estáticas
  staticPageGenerationTimeout: 0,
  experimental: {
    staticGenerationRetryCount: 0,
  },
  onDemandEntries: {
    maxInactiveAge: 1000 * 60 * 60, // 1 hora
    pagesBufferLength: 0,
  },
};
export default nextConfig;

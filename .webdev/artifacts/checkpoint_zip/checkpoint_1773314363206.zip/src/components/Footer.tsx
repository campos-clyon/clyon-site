import Link from "next/link";
import { Facebook, Instagram, Heart, Square, Lock } from "lucide-react";

export default function Footer() {
  return (
    <>
      <footer className="border-t border-cyan-100 bg-white py-14">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-10 mb-10">
            {/* Logo + descrição */}
            <div>
              <img
                src="/logo-clyon-icon.webp"
                alt="CLYON"
                className="h-10 w-auto mb-3"
                width="205"
                height="84"
              />
              <p className="text-sm text-slate-500 mb-5">
                Recolha e limpeza profissional em Lisboa e Setúbal.
              </p>
              <div className="flex gap-3 mb-5">
                <a
                  href="https://facebook.com/clyon.pt"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-xl flex items-center justify-center border border-cyan-200 text-cyan-600 hover:bg-cyan-50 transition"
                  aria-label="Facebook CLYON"
                >
                  <Facebook className="w-4 h-4" />
                </a>
                <a
                  href="https://instagram.com/clyon.pt"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-xl flex items-center justify-center border border-cyan-200 text-cyan-600 hover:bg-cyan-50 transition"
                  aria-label="Instagram CLYON"
                >
                  <Instagram className="w-4 h-4" />
                </a>
              </div>
              <Link
                href="/colaboradores"
                className="block w-full rounded-2xl bg-cyan-500 px-5 py-3 text-sm font-semibold text-white shadow-md shadow-cyan-200 transition hover:-translate-y-0.5 hover:bg-cyan-600 text-center"
              >
                Colaboradores
              </Link>
            </div>

            <div>
              <h3 className="font-semibold mb-4 text-sm uppercase tracking-wider text-slate-950">
                Serviços
              </h3>
              <ul className="space-y-2 text-sm text-slate-500">
                <li>
                  <Link href="/simulador" className="hover:text-cyan-600 transition-colors">
                    Solicitar serviço
                  </Link>
                </li>
                <li>
                  <Link href="/servicos" className="hover:text-cyan-600 transition-colors">
                    Nossos Serviços
                  </Link>
                </li>
                <li>
                  <Link href="/blog" className="hover:text-cyan-600 transition-colors">
                    Blog
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4 text-sm uppercase tracking-wider text-slate-950">
                Empresa
              </h3>
              <ul className="space-y-2 text-sm text-slate-500">
                <li>
                  <Link href="/sobre-nos" className="hover:text-cyan-600 transition-colors">
                    Sobre Nós
                  </Link>
                </li>
                <li>
                  <Link href="/central-ajuda" className="hover:text-cyan-600 transition-colors">
                    Central de Ajuda
                  </Link>
                </li>
                <li>
                  <Link href="/contactos" className="hover:text-cyan-600 transition-colors">
                    Contactos
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4 text-sm uppercase tracking-wider text-slate-950">
                Pagamentos
              </h3>
              <ul className="space-y-2 text-sm text-slate-500">
                <li className="flex items-center gap-2">
                  <Heart className="w-4 h-4 text-cyan-500" /> Revolut
                </li>
                <li className="flex items-center gap-2">
                  <Square className="w-4 h-4 text-cyan-500" /> MBWAY
                </li>
                <li className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-cyan-500" /> NOVO BANCO
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-8 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-slate-400">
              © CLYON 2025 — Todos os direitos reservados
            </p>
            <Link
              href="/privacidade"
              className="text-sm text-slate-400 hover:text-cyan-600 transition-colors"
            >
              Política de Privacidade
            </Link>
          </div>
        </div>
      </footer>

      {/* Botão flutuante WhatsApp */}
      <a
        href="https://wa.me/351931632622"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-green-500 shadow-lg shadow-green-200 transition hover:-translate-y-1 hover:bg-green-600"
        aria-label="Contactar via WhatsApp"
      >
        <svg viewBox="0 0 24 24" className="w-7 h-7 fill-white" xmlns="http://www.w3.org/2000/svg">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
        </svg>
      </a>
    </>
  );
}

"use client";

import Link from "next/link";
import { Menu, X, ArrowRight, MessageCircle } from "lucide-react";
import { useState } from "react";

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  const navLinks = [
    { label: "Serviços", href: "/servicos" },
    { label: "Trabalhos", href: "/trabalhos" },
    { label: "Avaliações", href: "/avaliacoes" },
    { label: "Sobre Nós", href: "/sobre-nos" },
    { label: "Contacto", href: "/contactos" },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white shadow-sm">
      <div className="mx-auto flex w-full items-center justify-between px-6 py-4 lg:px-12">
        {/* Logo */}
        <Link href="/" className="cursor-pointer flex-shrink-0">
          <img
            src="/logo-clyon-icon.webp"
            alt="CLYON - Recolha de Móveis e Entulho"
            className="h-8 w-auto"
            width="205"
            height="84"
          />
        </Link>

        {/* Desktop Navigation - Centered */}
        <nav className="flex flex-1 items-center justify-center gap-8 text-sm font-medium text-slate-600 md:flex">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="relative transition hover:text-cyan-600 after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-cyan-500 after:transition-all hover:after:w-full"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* CTAs - Right aligned */}
        <div className="flex items-center gap-4 lg:gap-6 flex-shrink-0">
          <Link
            href="/trabalhos"
            className="hidden rounded-full px-5 py-2.5 text-sm font-semibold transition hover:bg-cyan-50 lg:inline-flex"
            style={{border: "2px solid #00BCD4", color: "#00BCD4"}}
          >
            Ver Trabalhos
          </Link>
          <Link
            href="/simulador"
            className="rounded-full px-6 py-2.5 text-sm font-semibold text-white shadow-lg transition hover:shadow-xl flex items-center gap-2"
            style={{backgroundColor: "#00BCD4"}}
          >
            Pedir Orçamento
            <ArrowRight className="w-4 h-4" />
          </Link>
          {/* Mobile toggle */}
          <button
            className="lg:hidden p-2 rounded-lg text-slate-600 hover:text-cyan-600 transition-colors"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Abrir menu"
          >
            {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="lg:hidden border-t border-cyan-100 bg-white/95 backdrop-blur">
          <nav className="px-6 py-4 space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="block px-4 py-3 rounded-xl text-sm font-medium text-slate-600 hover:text-cyan-600 hover:bg-cyan-50 transition-colors"
                onClick={() => setMenuOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <div className="pt-3 space-y-2">
              <Link
                href="/simulador"
                className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl font-semibold text-white shadow-lg transition hover:shadow-xl"
                style={{backgroundColor: "#00BCD4"}}
                onClick={() => setMenuOpen(false)}
              >
                <ArrowRight className="w-4 h-4" />
                Pedir Orçamento
              </Link>
              <button
                className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl font-semibold border hover:bg-cyan-50 transition"
                style={{border: "1px solid #00BCD4", color: "#00BCD4"}}
                onClick={() => {
                  window.open("https://wa.me/351931632622", "_blank");
                  setMenuOpen(false);
                }}
              >
                <MessageCircle className="w-4 h-4" />
                WhatsApp
              </button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}

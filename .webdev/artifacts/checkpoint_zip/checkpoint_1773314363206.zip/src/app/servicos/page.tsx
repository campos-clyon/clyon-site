import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Phone } from "lucide-react";

export const metadata: Metadata = {
  title: "Serviços de Recolha e Limpeza | CLYON",
  description:
    "Conheça todos os serviços CLYON: recolha de móveis, entulho, monos, limpeza pós-obra, mudanças e muito mais. Orçamentos grátis.",
  keywords: [
    "serviços de recolha",
    "recolha de móveis",
    "recolha de entulho",
    "limpeza pós-obra",
    "mudanças lisboa",
  ],
  alternates: { canonical: "https://clyon.pt/servicos" },
  openGraph: {
    title: "Serviços de Recolha e Limpeza | CLYON",
    description: "Conheça todos os serviços CLYON: recolha de móveis, entulho, monos, limpeza pós-obra e mudanças.",
    url: "https://clyon.pt/servicos",
  },
};

const serviceCategories = [
  { id: 1, name: "Recolha de Monos", icon: "♻️", description: "Remoção segura e profissional de monos, sucata e materiais diversos. Limpeza completa do espaço após recolha.", simulatorCategory: "monos" },
  { id: 2, name: "Recolha de Recheios", icon: "🛋️", description: "Esvaziamos e recolhemos recheios completos de casas, apartamentos e vivendas com total eficiência.", simulatorCategory: "moveis" },
  { id: 3, name: "Esvaziamento de Casas", icon: "🏠", description: "Serviço completo de esvaziamento para venda, arrendamento ou renovação do seu imóvel.", simulatorCategory: "moveis" },
  { id: 4, name: "Serviço de Limpeza", icon: "🧹", description: "Limpezas profissionais de imóveis: pós-obra, pós-despejo, casas abandonadas e situações especiais.", simulatorCategory: "limpeza" },
  { id: 5, name: "Mudanças e Apoio", icon: "📦", description: "Serviço completo de mudança residencial ou comercial com profissionais qualificados.", simulatorCategory: "mudancas" },
  { id: 6, name: "Aluguer Caminhão + Motorista", icon: "🚚", description: "Aluguel de caminhão com motorista profissional para transporte de carga e mudanças.", simulatorCategory: "mudancas" },
  { id: 7, name: "Desmantelamento", icon: "🔧", description: "Desmontagem de estruturas, móveis e instalações com profissionalismo e cuidado.", simulatorCategory: "entulho" },
  { id: 8, name: "Reparações Domésticas", icon: "🔨", description: "Pequenos reparos e manutenção doméstica realizada por profissionais qualificados.", simulatorCategory: "moveis" },
];

const services = [
  { id: 1, name: "Recolha de Móveis", description: "Recolha segura e rápida de móveis velhos, danificados ou indesejados. Transporte direto para reciclagem ou doação.", image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663108032375/9kEaxw5PeTniExyaRSHpgx/srv-moveis-oK535m27dvMeha7PEEJxBk.webp" },
  { id: 2, name: "Recolha de Monos", description: "Remoção profissional de monos, sucata e materiais diversos. Limpeza completa do espaço após recolha.", image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663108032375/9kEaxw5PeTniExyaRSHpgx/srv-monos-kgdaeFx2LEotpqEgWX735B.webp" },
  { id: 3, name: "Recolha de Entulho", description: "Limpeza profissional de entulho de obras, reformas e demolições. Transporte e disposição adequada.", image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663108032375/9kEaxw5PeTniExyaRSHpgx/srv-entulho-8mczhgdWKNXtn3yrBUZSr5.webp" },
  { id: 4, name: "Esvaziamento de Casas", description: "Esvaziamento completo de casas, apartamentos e vivendas. Ideal para venda, arrendamento ou renovação.", image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663108032375/9kEaxw5PeTniExyaRSHpgx/srv-esvaziamento-QPGkqk4kW9RzSxPGeFBRTG.webp" },
  { id: 5, name: "Limpeza Pós-Obra", description: "Limpeza profissional após obras e remodelações. Espaço pronto a usar no mesmo dia.", image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663108032375/9kEaxw5PeTniExyaRSHpgx/srv-limpeza-8MNUx8b7oxs5ymfpQrfExs.webp" },
  { id: 6, name: "Mudanças", description: "Serviço completo de mudança residencial ou comercial. Embalagem, transporte e desembalagem profissional.", image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663108032375/9kEaxw5PeTniExyaRSHpgx/srv-mudancas-auFHFFvpfWCayi4kQn4nBY.webp" },
  { id: 7, name: "Aluguer de Caminhão com Motorista", description: "Aluguer de caminhão com motorista profissional para transporte de carga. Disponível para mudanças, entregas e recolhas.", image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663108032375/9kEaxw5PeTniExyaRSHpgx/srv-caminhao-aVJXAJ7pk6UBHTUm6HX6Ze.webp" },
  { id: 8, name: "Desmantelamento", description: "Desmontagem de estruturas, móveis e instalações com profissionalismo e cuidado.", image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663108032375/9kEaxw5PeTniExyaRSHpgx/srv-desmantelamento-K6q3RShYnsihWtqcV3Ubmy.webp" },
  { id: 9, name: "Reparações Domésticas", description: "Pequenos reparos e manutenção doméstica realizados por profissionais qualificados.", image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663108032375/9kEaxw5PeTniExyaRSHpgx/srv-reparacoes-jpK8aF26TwwoocyRMXbgBj.webp" },
];

export default function ServicosPage() {
  return (
    <div className="min-h-screen bg-white flex flex-col">

      {/* Hero */}
      <section className="pt-32 pb-20 bg-cyan-500 text-white text-center">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Melhore a sua qualidade de vida com serviços domiciliares.
          </h1>
          <p className="text-white/90 text-lg">
            Encontre profissionais qualificados para todos os seus serviços
          </p>
        </div>
      </section>

      {/* Categorias */}
      <section className="py-20 bg-white">
        <div className="flex justify-center px-4">
          <div className="w-full max-w-6xl">
            <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Categorias de Serviços</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {serviceCategories.map((category) => (
                <Link
                  key={category.id}
                  href={`/simulador?categoria=${category.simulatorCategory}`}
                  className="bg-white rounded-2xl border border-cyan-100 shadow-sm hover:shadow-lg hover:border-cyan-300 transition-all hover:scale-105 p-6 cursor-pointer block"
                >
                  <div className="flex flex-col items-center justify-center mb-4">
                    <div className="text-5xl mb-3">{category.icon}</div>
                    <h3 className="text-lg font-bold text-slate-900 text-center">{category.name}</h3>
                  </div>
                  <p className="text-slate-600 text-sm text-center">{category.description}</p>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Serviços com imagens */}
      <section className="py-20 bg-cyan-50">
        <div className="flex justify-center px-4">
          <div className="w-full max-w-6xl">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-slate-900">Serviços CLYON</h2>
              <p className="text-lg text-slate-600">Conheça todos os serviços que a CLYON oferece para si</p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              {services.map((service) => (
                <div key={service.id} className="bg-white rounded-lg overflow-hidden border border-cyan-100 shadow-sm hover:shadow-lg hover:border-cyan-300 transition-all">
                  <div className="w-full h-48 overflow-hidden bg-cyan-100">
                    <img
                      src={service.image}
                      alt={service.name}
                      className="w-full h-full object-cover hover:scale-105 transition-transform"
                      loading="lazy"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-slate-900 mb-2">{service.name}</h3>
                    <p className="text-slate-600 text-sm mb-4">{service.description}</p>
                    <div className="flex items-center justify-end">
                      <a
                        href="https://wa.me/351931632622"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 bg-cyan-500 hover:bg-cyan-600 text-white text-sm font-semibold px-4 py-2 rounded-lg transition"
                      >
                        Contratar
                        <ArrowRight className="w-4 h-4" />
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-cyan-500 text-white">
        <div className="flex justify-center px-4">
          <div className="w-full max-w-6xl text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Pronto para começar?</h2>
            <p className="text-lg mb-8 text-white/90">Contacte-nos agora e receba uma resposta em até 11 minutos!</p>
            <a
              href="https://wa.me/351931632622"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-white text-cyan-600 hover:bg-cyan-50 font-semibold px-8 py-4 rounded-2xl shadow-lg transition text-lg"
            >
              <Phone className="w-5 h-5" />
              Contactar via WhatsApp
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
export const dynamic = 'force-dynamic';

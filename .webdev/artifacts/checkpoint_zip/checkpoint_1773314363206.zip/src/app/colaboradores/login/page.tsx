import type { Metadata } from "next";
import ColaboradorLoginClient from "./ColaboradorLoginClient";

export const metadata: Metadata = {
  title: "Portal do Colaborador | CLYON",
  robots: { index: false, follow: false },
};

export default function ColaboradorLoginPage() {
  return <ColaboradorLoginClient />;
}
export const dynamic = 'force-dynamic';

import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { CheckCircle2, Phone, MapPin, Clock, Star } from "lucide-react";

// Dados das cidades
const cities: Record<string, { name: string; region: string; district: string }> = {
  lisboa: { name: "Lisboa", region: "Lisboa", district: "Lisboa" },
  almada: { name: "Almada", region: "Margem Sul", district: "Setúbal" },
  seixal: { name: "Seixal", region: "Margem Sul", district: "Setúbal" },
  barreiro: { name: "Barreiro", region: "Margem Sul", district: "Setúbal" },
  moita: { name: "Moita", region: "Margem Sul", district: "Setúbal" },
  setubal: { name: "Setúbal", region: "Setúbal", district: "Setúbal" },
  palmela: { name: "Palmela", region: "Setúbal", district: "Setúbal" },
  sesimbra: { name: "Sesimbra", region: "Setúbal", district: "Setúbal" },
  montijo: { name: "Montijo", region: "Margem Sul", district: "Setúbal" },
  alcochete: { name: "Alcochete", region: "Margem Sul", district: "Setúbal" },
  sintra: { name: "Sintra", region: "Grande Lisboa", district: "Lisboa" },
  cascais: { name: "Cascais", region: "Grande Lisboa", district: "Lisboa" },
  oeiras: { name: "Oeiras", region: "Grande Lisboa", district: "Lisboa" },
  amadora: { name: "Amadora", region: "Grande Lisboa", district: "Lisboa" },
  loures: { name: "Loures", region: "Grande Lisboa", district: "Lisboa" },
  odivelas: { name: "Odivelas", region: "Grande Lisboa", district: "Lisboa" },
  mafra: { name: "Mafra", region: "Grande Lisboa", district: "Lisboa" },
  "vila-franca": { name: "Vila Franca de Xira", region: "Grande Lisboa", district: "Lisboa" },
  benfica: { name: "Benfica", region: "Lisboa", district: "Lisboa" },
  lumiar: { name: "Lumiar", region: "Lisboa", district: "Lisboa" },
};

// Dados dos serviços
const services: Record<string, { name: string; description: string; keywords: string[] }> = {
  "recolha-moveis": {
    name: "Recolha de Móveis",
    description: "Recolha segura e rápida de móveis velhos, danificados ou indesejados. Transporte direto para reciclagem ou doação.",
    keywords: ["recolha de móveis", "remoção de móveis", "levar móveis velhos"],
  },
  "recolha-entulho": {
    name: "Recolha de Entulho",
    description: "Limpeza profissional de entulho de obras, reformas e demolições. Transporte e disposição adequada.",
    keywords: ["recolha de entulho", "remoção de entulho", "limpeza de obras"],
  },
  "recolha-monos": {
    name: "Recolha de Monos",
    description: "Remoção profissional de monos, sucata e materiais diversos. Limpeza completa do espaço após recolha.",
    keywords: ["recolha de monos", "remoção de monos", "sucata"],
  },
  "esvaziamento-casas": {
    name: "Esvaziamento de Casas",
    description: "Esvaziamento completo de casas, apartamentos e vivendas. Ideal para venda, arrendamento ou renovação.",
    keywords: ["esvaziamento de casas", "esvaziar casa", "limpeza de imóvel"],
  },
  "limpeza-pos-obra": {
    name: "Limpeza Pós-Obra",
    description: "Limpeza profissional após obras e remodelações. Espaço pronto a usar no mesmo dia.",
    keywords: ["limpeza pós-obra", "limpeza após obra", "limpeza de construção"],
  },
  mudancas: {
    name: "Mudanças",
    description: "Serviço completo de mudança residencial ou comercial. Embalagem, transporte e desembalagem profissional.",
    keywords: ["mudanças", "empresa de mudanças", "transporte de móveis"],
  },
};

// Função para parsear o slug e encontrar serviço + cidade
function parseSlug(slug: string[]): { serviceKey: string | null; cityKey: string | null } {
  const fullSlug = slug.join("/");
  
  // Tentar encontrar qual serviço e cidade correspondem ao slug
  for (const serviceKey of Object.keys(services)) {
    for (const cityKey of Object.keys(cities)) {
      const expected = `${serviceKey}-${cityKey}`;
      if (fullSlug === expected) {
        return { serviceKey, cityKey };
      }
    }
  }
  return { serviceKey: null, cityKey: null };
}

type Props = {
  params: Promise<{ slug: string[] }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const { serviceKey, cityKey } = parseSlug(slug);

  if (!serviceKey || !cityKey) {
    return { title: "Página não encontrada | CLYON" };
  }

  const cityData = cities[cityKey];
  const serviceData = services[serviceKey];
  const urlSlug = slug.join("/");

  const title = `${serviceData.name} em ${cityData.name}`;
  const description = `${serviceData.name} em ${cityData.name}, ${cityData.region}. Serviço rápido, profissional e com orçamento gratuito em 11 minutos. Ligue já!`;

  return {
    title,
    description,
    keywords: [...serviceData.keywords, cityData.name, cityData.region, "CLYON"],
    alternates: {
      canonical: `https://clyon.pt/${urlSlug}`,
      languages: { "pt-PT": `https://clyon.pt/${urlSlug}` },
    },
    openGraph: {
      title,
      description,
      url: `https://clyon.pt/${urlSlug}`,
      locale: "pt_PT",
    },
  };
}

// Desabilitar geração de páginas estáticas - usar apenas SSR
// export async function generateStaticParams() {
//   const params = [];
//   for (const cityKey of Object.keys(cities)) {
//     for (const serviceKey of Object.keys(services)) {
//       params.push({ slug: [`${serviceKey}-${cityKey}`] });
//     }
//   }
//   return params;
// }

export const dynamic = 'force-dynamic';

export default async function ServiceCityPage({ params }: Props) {
  const { slug } = await params;
  const { serviceKey, cityKey } = parseSlug(slug);

  if (!serviceKey || !cityKey) {
    notFound();
  }

  const cityData = cities[cityKey!];
  const serviceData = services[serviceKey!];
  const urlSlug = slug.join("/");

  const faqs = [
    {
      q: `Quanto custa ${serviceData.name.toLowerCase()} em ${cityData.name}?`,
      a: `O preço varia conforme o volume e tipo de material. Oferecemos orçamento gratuito em menos de 11 minutos. Contacte-nos agora!`,
    },
    {
      q: `Fazem ${serviceData.name.toLowerCase()} ao fim de semana em ${cityData.name}?`,
      a: `Sim! Trabalhamos 7 dias por semana, incluindo fins de semana e feriados, para a sua conveniência.`,
    },
    {
      q: `Qual é o prazo para ${serviceData.name.toLowerCase()} em ${cityData.name}?`,
      a: `Na maioria dos casos conseguimos realizar o serviço no mesmo dia ou no dia seguinte. Contacte-nos para verificar disponibilidade.`,
    },
    {
      q: `A CLYON tem certificação para ${serviceData.name.toLowerCase()}?`,
      a: `Sim. A CLYON possui certificação APA (Agência Portuguesa do Ambiente) para transporte e gestão de resíduos.`,
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-cyan-500 to-cyan-600 text-white pt-32 pb-20">
        <div
          className="absolute inset-0 opacity-10"
          style={{ backgroundImage: "radial-gradient(circle, white 1px, transparent 1px)", backgroundSize: "32px 32px" }}
        />
        <div className="relative max-w-5xl mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 px-4 py-2 text-sm font-medium mb-6">
            <MapPin className="w-4 h-4" />
            {cityData.name}, {cityData.region}
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            {serviceData.name} em {cityData.name}
          </h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto mb-8">
            {serviceData.description} Serviço profissional em {cityData.name} e região de {cityData.region}.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/simulador"
              className="rounded-2xl bg-white px-8 py-4 text-base font-bold text-cyan-700 shadow-xl transition hover:-translate-y-0.5 hover:shadow-2xl text-center"
            >
              Pedir Orçamento Grátis
            </Link>
            <a
              href="https://wa.me/351931632622"
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-2xl border border-white/40 px-8 py-4 text-base font-bold text-white transition hover:bg-white/10 flex items-center gap-2 justify-center"
            >
              <Phone className="w-5 h-5" />
              WhatsApp
            </a>
          </div>
        </div>
      </section>

      {/* Benefícios */}
      <section className="py-16 bg-white">
        <div className="max-w-5xl mx-auto px-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-8 text-center">
            Por que escolher a CLYON para {serviceData.name.toLowerCase()} em {cityData.name}?
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: Clock, title: "Resposta em 11 minutos", desc: "Orçamento gratuito e rápido, sem compromisso" },
              { icon: Star, title: "5.0★ no Fixando", desc: "163 avaliações de clientes reais e satisfeitos" },
              { icon: CheckCircle2, title: "Certificação APA", desc: "Gestão responsável e legal de todos os resíduos" },
            ].map((item) => (
              <div key={item.title} className="rounded-[24px] border border-cyan-100 bg-cyan-50/50 p-6 flex gap-4">
                <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl bg-cyan-500 text-white">
                  <item.icon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900">{item.title}</h3>
                  <p className="mt-1 text-sm text-slate-600">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 bg-cyan-50/60">
        <div className="max-w-3xl mx-auto px-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-8 text-center">
            Perguntas frequentes sobre {serviceData.name.toLowerCase()} em {cityData.name}
          </h2>
          <div className="space-y-4">
            {faqs.map((faq, idx) => (
              <div key={idx} className="rounded-[20px] bg-white border border-cyan-100 p-6 shadow-sm">
                <h3 className="font-semibold text-slate-900 mb-2">{faq.q}</h3>
                <p className="text-slate-600 text-sm leading-7">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-16 bg-slate-950 text-white">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold mb-4">
            Pronto para resolver em {cityData.name}?
          </h2>
          <p className="text-slate-400 mb-8">
            Orçamento gratuito em 11 minutos. Recolha no mesmo dia em {cityData.name} e região.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/simulador"
              className="rounded-2xl bg-cyan-500 px-8 py-4 text-base font-bold text-white shadow-lg shadow-cyan-500/30 transition hover:bg-cyan-400 text-center"
            >
              Pedir Orçamento Grátis
            </Link>
            <a
              href="https://wa.me/351931632622"
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-2xl border border-white/20 px-8 py-4 text-base font-bold text-white transition hover:bg-white/10 flex items-center gap-2 justify-center"
            >
              <Phone className="w-5 h-5" />
              Falar no WhatsApp
            </a>
          </div>
        </div>
      </section>

      {/* Schema.org JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Service",
            name: `${serviceData.name} em ${cityData.name}`,
            description: serviceData.description,
            provider: {
              "@type": "LocalBusiness",
              name: "CLYON",
              telephone: "+351931632622",
              url: "https://clyon.pt",
              address: {
                "@type": "PostalAddress",
                addressLocality: cityData.name,
                addressRegion: cityData.district,
                addressCountry: "PT",
              },
            },
            areaServed: { "@type": "City", name: cityData.name },
          }),
        }}
      />
    </div>
  );
}

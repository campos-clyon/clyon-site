import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { TrpcProvider } from "@/components/TrpcProvider";

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://clyon.pt"),
  title: {
    default: "Recolha de Entulho, Móveis e Monos em Lisboa e Setúbal | CLYON",
    template: "%s | CLYON",
  },
  description:
    "Recolha de entulho, móveis e monos em Lisboa e Setúbal. Orçamento grátis em 11 minutos. Recolha no mesmo dia.",
  keywords: ["recolha entulho Lisboa", "recolha móveis Lisboa", "recolha monos", "esvaziamento casas", "limpeza pós-obra"],
  authors: [{ name: "CLYON" }],
  creator: "CLYON",
  publisher: "CLYON",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  openGraph: {
    type: "website",
    locale: "pt_PT",
    url: "https://clyon.pt",
    siteName: "CLYON",
    title: "Recolha de Entulho, Móveis e Monos em Lisboa e Setúbal | CLYON",
    description:
      "Recolha de entulho, móveis e monos em Lisboa e Setúbal. Orçamento grátis em 11 minutos. Recolha no mesmo dia.",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "CLYON - Recolha de Entulho e Móveis",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Recolha de Entulho, Móveis e Monos em Lisboa e Setúbal | CLYON",
    description:
      "Recolha de entulho, móveis e monos em Lisboa e Setúbal. Orçamento grátis em 11 minutos.",
    images: ["/og-image.jpg"],
  },
  alternates: {
    canonical: "https://clyon.pt",
    languages: {
      "pt-PT": "https://clyon.pt",
    },
  },
  other: {
    "geo.region": "PT-11",
    "geo.placename": "Lisboa, Portugal",
    "geo.position": "38.7223;-9.1393",
    ICBM: "38.7223, -9.1393",
    language: "Portuguese",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-PT" className={inter.variable}>
      <head>
        <script dangerouslySetInnerHTML={{
          __html: `
            (function() {
              document.documentElement.style.colorScheme = 'light';
              document.documentElement.classList.remove('dark');
              document.body.style.backgroundColor = '#ffffff';
              document.body.style.color = '#0f172a';
            })();
          `
        }} />
        <meta name="color-scheme" content="light" />
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="manifest" href="/site.webmanifest" />
        <meta name="theme-color" content="#00B4CC" />
        {/* Schema.org LocalBusiness */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "LocalBusiness",
              name: "CLYON",
              description:
                "Empresa especializada em recolha de entulho, móveis, monos e esvaziamento de casas em Lisboa e Setúbal.",
              url: "https://clyon.pt",
              telephone: "+351931632622",
              email: "geral@clyon.pt",
              address: {
                "@type": "PostalAddress",
                addressLocality: "Lisboa",
                addressRegion: "Lisboa",
                addressCountry: "PT",
              },
              geo: {
                "@type": "GeoCoordinates",
                latitude: 38.7223,
                longitude: -9.1393,
              },
              areaServed: [
                "Lisboa",
                "Setúbal",
                "Almada",
                "Cascais",
                "Sintra",
                "Oeiras",
                "Amadora",
                "Loures",
                "Seixal",
                "Barreiro",
              ],
              openingHoursSpecification: [
                {
                  "@type": "OpeningHoursSpecification",
                  dayOfWeek: [
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday",
                  ],
                  opens: "08:00",
                  closes: "20:00",
                },
              ],
              sameAs: [
                "https://facebook.com/clyon.pt",
                "https://instagram.com/clyon.pt",
              ],
            }),
          }}
        />
      </head>
      <body className="min-h-screen bg-white text-slate-900 antialiased">
        <TrpcProvider>
          <Header />
          <main>{children}</main>
          <Footer />
        </TrpcProvider>
      </body>
    </html>
  );
}

import type { Metadata } from "next";
import Link from "next/link";
import { CheckCircle2, Star, Users, Award, Clock } from "lucide-react";

export const metadata: Metadata = {
  title: "Sobre Nós | CLYON — Empresa de Recolha e Limpeza em Lisboa",
  description:
    "Conheça a CLYON: empresa certificada APA, Top Pro no Fixando com 163 avaliações 5 estrelas. Recolha de entulho, móveis, monos e limpeza em Lisboa e Setúbal.",
  keywords: ["sobre clyon", "empresa de recolha lisboa", "certificação APA", "top pro fixando"],
  alternates: { canonical: "https://clyon.pt/sobre-nos" },
  openGraph: {
    title: "Sobre Nós | CLYON",
    description: "Empresa certificada APA, Top Pro no Fixando. Recolha e limpeza em Lisboa e Setúbal.",
    url: "https://clyon.pt/sobre-nos",
  },
};

const stats = [
  { icon: Star, value: "5.0★", label: "Avaliação média no Fixando" },
  { icon: Users, value: "163+", label: "Clientes satisfeitos" },
  { icon: Clock, value: "11 min", label: "Tempo médio de resposta" },
  { icon: Award, value: "APA", label: "Certificação ambiental" },
];

const values = [
  { title: "Rapidez", desc: "Respondemos em 11 minutos e realizamos o serviço no mesmo dia sempre que possível." },
  { title: "Profissionalismo", desc: "Equipa treinada, uniformizada e com equipamento adequado para cada tipo de trabalho." },
  { title: "Responsabilidade Ambiental", desc: "Certificação APA garante gestão legal e responsável de todos os resíduos recolhidos." },
  { title: "Transparência", desc: "Orçamentos claros, sem surpresas. O preço que apresentamos é o preço que cobra." },
];

export default function SobreNosPage() {
  return (
    <div className="min-h-screen bg-white">

      {/* Hero */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-slate-900 to-slate-800 text-white">
        <div className="max-w-5xl mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm font-medium mb-6">
            <Award className="w-4 h-4" />
            Certificação APA — Agência Portuguesa do Ambiente
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Quem é a CLYON?
          </h1>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            Somos uma empresa especializada em recolha de resíduos, limpeza e mudanças em Lisboa, Setúbal e Margem Sul.
            Fundada com o objetivo de oferecer um serviço rápido, profissional e ambientalmente responsável.
          </p>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 bg-cyan-50">
        <div className="max-w-5xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat) => (
              <div key={stat.label} className="rounded-[24px] bg-white border border-cyan-100 p-6 text-center shadow-sm">
                <div className="flex justify-center mb-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500 text-white">
                    <stat.icon className="w-5 h-5" />
                  </div>
                </div>
                <div className="text-2xl font-bold text-slate-900">{stat.value}</div>
                <div className="text-sm text-slate-500 mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Missão */}
      <section className="py-16 bg-white">
        <div className="max-w-5xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-6">A nossa missão</h2>
              <p className="text-slate-600 leading-8 mb-4">
                A CLYON nasceu da necessidade de oferecer um serviço de recolha e limpeza verdadeiramente profissional
                em Lisboa e região. Percebemos que muitos clientes enfrentavam dificuldades em encontrar empresas
                confiáveis, rápidas e com preços transparentes.
              </p>
              <p className="text-slate-600 leading-8">
                Hoje somos reconhecidos como Top Pro no Fixando, com 163 avaliações de 5 estrelas e um tempo de
                resposta médio de apenas 11 minutos. A nossa certificação APA garante que todos os resíduos são
                geridos de forma legal e responsável.
              </p>
            </div>
            <div className="space-y-4">
              {values.map((v) => (
                <div key={v.title} className="flex gap-4 rounded-[20px] border border-cyan-100 p-5 bg-cyan-50/50">
                  <CheckCircle2 className="w-5 h-5 text-cyan-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-slate-900">{v.title}</h3>
                    <p className="text-sm text-slate-600 mt-1">{v.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-cyan-500 text-white text-center">
        <div className="max-w-3xl mx-auto px-6">
          <h2 className="text-3xl font-bold mb-4">Pronto para trabalhar connosco?</h2>
          <p className="text-white/90 mb-8">Orçamento gratuito em 11 minutos. Sem compromisso.</p>
          <Link
            href="/simulador"
            className="inline-block rounded-2xl bg-white px-8 py-4 text-base font-bold text-cyan-700 shadow-xl transition hover:-translate-y-0.5"
          >
            Pedir Orçamento Grátis
          </Link>
        </div>
      </section>
    </div>
  );
}
export const dynamic = 'force-dynamic';

import type { Metadata } from "next";
import FAQClient from "./FAQClient";

export const metadata: Metadata = {
  title: "Perguntas Frequentes | CLYON",
  description:
    "Encontre respostas para as perguntas mais frequentes sobre serviços de recolha, limpeza, mudanças e mais. Saiba como a CLYON pode ajudar.",
  keywords: ["faq clyon", "perguntas frequentes", "recolha de entulho preço", "mudanças preço"],
  alternates: { canonical: "https://clyon.pt/faq" },
  openGraph: {
    title: "Perguntas Frequentes | CLYON",
    description: "Respostas às perguntas mais frequentes sobre serviços CLYON.",
    url: "https://clyon.pt/faq",
  },
};

const faqCategories = [
  {
    category: "Serviços Gerais",
    questions: [
      { q: "Qual é o tempo de resposta da CLYON?", a: "Respondemos em até 11 minutos para solicitar um orçamento. Nosso objetivo é fornecer respostas rápidas e eficientes para todos os clientes." },
      { q: "Quais regiões a CLYON atende?", a: "Atendemos Lisboa, Setúbal e Margem Sul com serviços profissionais de limpeza, recolha de entulho e mudanças. Podemos expandir para outras regiões mediante consulta." },
      { q: "Como posso contratar um serviço?", a: "Pode contratar através do nosso site usando o Simulador de Orçamento, entrando em contacto via WhatsApp (+351 931 632 622) ou preenchendo o formulário de solicitação de serviço." },
      { q: "Qual é a taxa de satisfação da CLYON?", a: "100% dos nossos clientes estão satisfeitos com os nossos serviços. Somos Top Pro no Fixando com avaliações de 5 estrelas." },
    ],
  },
  {
    category: "Simulador de Orçamento",
    questions: [
      { q: "Como funciona o simulador de orçamento?", a: "Aceda ao simulador, selecione o tipo de serviço (Móveis, Entulho, Mudanças, etc.), preencha os dados solicitados e receba um orçamento instantâneo com o preço final." },
      { q: "O orçamento é vinculativo?", a: "O orçamento fornecido pelo simulador é uma estimativa. O preço final pode variar dependendo de fatores como acessibilidade, complexidade do trabalho e condições no local." },
      { q: "Posso modificar o orçamento após receber?", a: "Sim, pode entrar em contacto connosco via WhatsApp ou telefone para discutir modificações no orçamento antes de confirmar o serviço." },
    ],
  },
  {
    category: "Recolha de Entulho",
    questions: [
      { q: "Quanto custa a recolha de entulho?", a: "O preço depende da quantidade de entulho, localização e acessibilidade. Use o nosso simulador para obter um orçamento instantâneo." },
      { q: "Vocês recolhem entulho de qualquer tipo?", a: "Recolhemos a maioria dos tipos de entulho de obras, reformas e demolições. Para materiais especiais (amianto, resíduos perigosos), entre em contacto connosco." },
      { q: "Qual é o tempo de recolha?", a: "O tempo depende da quantidade e localização. Geralmente, conseguimos agendar a recolha em 24-48 horas após confirmação." },
    ],
  },
  {
    category: "Mudanças",
    questions: [
      { q: "Vocês oferecem serviço completo de mudança?", a: "Sim, oferecemos serviço completo incluindo embalagem, transporte, desembalagem e montagem de móveis no novo local." },
      { q: "Como é calculado o preço de uma mudança?", a: "O preço é baseado no tempo estimado, número de pessoas, distância entre endereços, e acessibilidade. Use o simulador para calcular." },
      { q: "Vocês oferecem seguro para os móveis?", a: "Todos os móveis são tratados com máximo cuidado. Entre em contacto para discutir opções de cobertura de seguro para mudanças de alto valor." },
    ],
  },
  {
    category: "Recolha de Móveis",
    questions: [
      { q: "Vocês recolhem móveis velhos ou danificados?", a: "Sim, recolhemos móveis velhos, danificados ou indesejados. Transportamos para reciclagem ou doação conforme apropriado." },
      { q: "Qual é o custo de recolha de móveis?", a: "O custo depende da quantidade e tipo de móveis. Use o nosso simulador para obter um orçamento rápido e preciso." },
    ],
  },
  {
    category: "Pagamento e Políticas",
    questions: [
      { q: "Quais são as formas de pagamento?", a: "Aceitamos transferência bancária, multibanco, e pagamento via WhatsApp. Discuta a forma de pagamento ao agendar o serviço." },
      { q: "Vocês oferecem desconto para múltiplos serviços?", a: "Sim, oferecemos descontos para clientes que contratam múltiplos serviços. Entre em contacto para discutir." },
      { q: "Qual é a política de cancelamento?", a: "Cancelamentos com 24 horas de antecedência não têm custo. Cancelamentos com menos de 24 horas podem estar sujeitos a taxa." },
    ],
  },
];

export default function FAQPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-cyan-500 to-cyan-600 text-white text-center">
        <div className="max-w-3xl mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Perguntas Frequentes</h1>
          <p className="text-white/90 text-lg">Encontre respostas rápidas sobre os nossos serviços</p>
        </div>
      </section>

      {/* FAQ Accordion (client component) */}
      <FAQClient categories={faqCategories} />

      {/* Schema.org FAQ */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            mainEntity: faqCategories.flatMap((cat) =>
              cat.questions.map((faq) => ({
                "@type": "Question",
                name: faq.q,
                acceptedAnswer: { "@type": "Answer", text: faq.a },
              }))
            ),
          }),
        }}
      />
    </div>
  );
}
export const dynamic = 'force-dynamic';

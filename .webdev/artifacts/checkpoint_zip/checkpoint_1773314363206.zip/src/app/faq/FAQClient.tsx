"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";

type FAQCategory = {
  category: string;
  questions: { q: string; a: string }[];
};

export default function FAQClient({ categories }: { categories: FAQCategory[] }) {
  const [openIndex, setOpenIndex] = useState<string | null>(null);

  return (
    <section className="py-16 bg-white">
      <div className="max-w-3xl mx-auto px-4 space-y-10">
        {categories.map((cat) => (
          <div key={cat.category}>
            <h2 className="text-xl font-bold text-slate-900 mb-4 border-b border-cyan-100 pb-2">
              {cat.category}
            </h2>
            <div className="space-y-3">
              {cat.questions.map((faq, idx) => {
                const key = `${cat.category}-${idx}`;
                const isOpen = openIndex === key;
                return (
                  <div
                    key={key}
                    className="rounded-[20px] border border-cyan-100 bg-white shadow-sm overflow-hidden"
                  >
                    <button
                      className="w-full flex items-center justify-between p-5 text-left font-semibold text-slate-900 hover:bg-cyan-50 transition"
                      onClick={() => setOpenIndex(isOpen ? null : key)}
                    >
                      <span>{faq.q}</span>
                      <ChevronDown
                        className={`w-5 h-5 text-cyan-500 flex-shrink-0 transition-transform ${isOpen ? "rotate-180" : ""}`}
                      />
                    </button>
                    {isOpen && (
                      <div className="px-5 pb-5 text-slate-600 text-sm leading-7">
                        {faq.a}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

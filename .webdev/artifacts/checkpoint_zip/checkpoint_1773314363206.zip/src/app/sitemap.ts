import type { MetadataRoute } from "next";

const cities = [
  "lisboa", "almada", "seixal", "barreiro", "moita", "setubal", "palmela",
  "sesimbra", "montijo", "alcochete", "sintra", "cascais", "oeiras",
  "amadora", "loures", "odivelas", "mafra", "vila_franca", "benfica", "lumiar",
];

const services = [
  "recolha-moveis", "recolha-entulho", "recolha-monos",
  "esvaziamento-casas", "limpeza-pos-obra", "mudancas",
];

const staticPages = [
  { url: "https://clyon.pt", priority: 1.0, changeFrequency: "weekly" as const },
  { url: "https://clyon.pt/servicos", priority: 0.9, changeFrequency: "weekly" as const },
  { url: "https://clyon.pt/simulador", priority: 0.9, changeFrequency: "monthly" as const },
  { url: "https://clyon.pt/trabalhos", priority: 0.8, changeFrequency: "weekly" as const },
  { url: "https://clyon.pt/avaliacoes", priority: 0.8, changeFrequency: "weekly" as const },
  { url: "https://clyon.pt/blog", priority: 0.8, changeFrequency: "weekly" as const },
  { url: "https://clyon.pt/faq", priority: 0.7, changeFrequency: "monthly" as const },
  { url: "https://clyon.pt/sobre-nos", priority: 0.7, changeFrequency: "monthly" as const },
  { url: "https://clyon.pt/contacto", priority: 0.6, changeFrequency: "monthly" as const },
];

export default function sitemap(): MetadataRoute.Sitemap {
  const localPages = cities.flatMap((cidade) =>
    services.map((servico) => ({
      url: `https://clyon.pt/${servico}-${cidade}`,
      lastModified: new Date(),
      changeFrequency: "monthly" as const,
      priority: 0.8,
    }))
  );

  return [
    ...staticPages.map((p) => ({ ...p, lastModified: new Date() })),
    ...localPages,
  ];
}

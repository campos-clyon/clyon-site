import type { Metadata } from "next";
import Link from "next/link";
import {
  Star,
  MapPin,
  ArrowRight,
  CheckCircle2,
  Truck,
  Home as HomeIcon,
  Trash2,
  Zap,
  MessageCircle,
  ChevronRight,
} from "lucide-react";
import ImageCarousel from "@/components/ImageCarousel";

export const metadata: Metadata = {
  title: "Recolha de Móveis e Entulho em Lisboa e Setúbal | CLYON",
  description:
    "Recolha de entulho, móveis e monos em Lisboa e Setúbal. Orçamento grátis em 11 minutos. Recolha no mesmo dia.",
  keywords: [
    "recolha de móveis lisboa",
    "recolha de entulho lisboa",
    "recolha de monos",
    "esvaziamento casas",
    "limpeza pós-obra",
  ],
  alternates: {
    canonical: "https://clyon.pt",
  },
  openGraph: {
    title: "Recolha de Móveis e Entulho em Lisboa e Setúbal | CLYON",
    description:
      "Recolha de entulho, móveis e monos em Lisboa e Setúbal. Orçamento grátis em 11 minutos.",
    url: "https://clyon.pt",
  },
};

const services = [
  {
    name: "Recolha de Entulho",
    description: "Remoção rápida e organizada para obras, remodelações e limpezas pesadas.",
    icon: Trash2,
  },
  {
    name: "Recolha de Móveis",
    description: "Retiramos móveis antigos, eletrodomésticos e volumes grandes sem complicações.",
    icon: HomeIcon,
  },
  {
    name: "Limpeza Pós-Obra",
    description: "Acabamentos impecáveis para deixar o espaço pronto a usar no mesmo dia.",
    icon: Zap,
  },
  {
    name: "Mudanças e Apoio",
    description: "Equipa de apoio para transporte, desmontagem e organização da mudança.",
    icon: Truck,
  },
  {
    name: "Recolha de Monos",
    description: "Limpeza de sótãos, caves e garagens com organização e eficiência.",
    icon: Trash2,
  },
  {
    name: "Aluguer Caminhão + Motorista",
    description: "Solução flexível para transporte de qualquer volume ou carga.",
    icon: Truck,
  },
  {
    name: "Desmantelamento",
    description: "Desmontagem profissional de estruturas, móveis e equipamentos complexos.",
    icon: Trash2,
  },
  {
    name: "Reparações Domésticas",
    description: "Pequenas reparações e manutenção geral da casa com profissionais qualificados.",
    icon: Truck,
  },
];

const steps = [
  {
    title: "Descreva o serviço em menos de 1 minuto",
    desc: "Conte-nos o que precisa: móveis, entulho, mudança completa ou limpeza pós-obra.",
    duration: "< 1 minuto",
    color: "bg-cyan-500",
    shadow: "shadow-cyan-500/40",
    ring: "ring-cyan-500/40",
    durationColor: "text-cyan-400",
  },
  {
    title: "Receba uma resposta rápida com orçamento claro",
    desc: "Em menos de 11 minutos recebe um orçamento transparente, sem surpresas nem custos ocultos.",
    duration: "< 11 minutos",
    color: "bg-purple-500",
    shadow: "shadow-purple-500/40",
    ring: "ring-purple-500/40",
    durationColor: "text-purple-400",
  },
  {
    title: "Agende o melhor horário e deixe connosco",
    desc: "Escolha a data e hora. A nossa equipa vai até si e realiza o trabalho no mesmo dia.",
    duration: "Mesmo dia",
    color: "bg-emerald-500",
    shadow: "shadow-emerald-500/40",
    ring: "ring-emerald-500/40",
    durationColor: "text-emerald-400",
  },
];

const testimonials = [
  { name: "Carlos F.", text: "Equipa profissional, pontual e muito cuidadosa. Ficou tudo limpo e resolvido sem stress.", rating: 5 },
  { name: "Inês A.", text: "Serviço rápido, preço justo e comunicação excelente do início ao fim.", rating: 5 },
  { name: "Christian M.", text: "Responderam no mesmo dia e executaram com muita eficiência. Recomendo sem hesitar.", rating: 5 },
  { name: "Maria T.", text: "Muito eficientes, boa relação qualidade preço. Estou extremamente satisfeita com o serviço.", rating: 5 },
  { name: "Patricia S.", text: "Serviço rápido e eficiente. Equipa muito simpática e profissional. Recomendo a toda a gente!", rating: 5 },
  { name: "Ana F.", text: "Trabalho impecável. Chegaram na hora combinada, foram rápidos e deixaram tudo limpo.", rating: 5 },
];

const stats = [
  { value: "5.0★", label: "avaliação média" },
  { value: "11 min", label: "tempo médio de resposta" },
  { value: "Mesmo dia", label: "disponibilidade em muitos pedidos" },
];

const whyUs = [
  { title: "Profissionais Verificados", desc: "Identidade verificada e avaliações reais de clientes" },
  { title: "Preço Transparente", desc: "Sem custos ocultos. Orçamento claro antes do serviço" },
  { title: "Resposta em 11 min", desc: "Orçamento em minutos. Agendamento flexível" },
  { title: "Avaliação 5.0 ★", desc: "Nota máxima de 163 clientes satisfeitos" },
  { title: "Garantia de Satisfação", desc: "Não satisfeito? Resolvemos sem custo adicional" },
  { title: "Suporte Dedicado", desc: "Equipa disponível para qualquer dúvida ou emergência" },
];

const workImages = [
  { url: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663108032375/dqCbsQzHnvaqyagS.jpeg", alt: "Recolha de Entulho", title: "Recolha de Entulho", subtitle: "Fotos reais dos nossos trabalhos" },
  { url: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663108032375/vhJtJOvSLMtalhnU.jpeg", alt: "Recolha de Móveis", title: "Recolha de Móveis", subtitle: "Remoção segura e profissional" },
  { url: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663108032375/FKTNuRqFLbPWJerM.jpeg", alt: "Mudanças Completas", title: "Mudanças Completas", subtitle: "Transporte profissional" },
  { url: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663108032375/hdfUMgNArMKsLzwf.jpeg", alt: "Limpeza de Quintais", title: "Limpeza de Quintais", subtitle: "Espaços limpos e organizados" },
  { url: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663108032375/QRBPwUyLyiTpDsXi.jpeg", alt: "Recolha de Monos", title: "Recolha de Monos", subtitle: "Sótãos, caves e garagens" },
  { url: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663108032375/xVyYzBjdoinaOLEs.jpeg", alt: "Demolição Controlada", title: "Demolição Controlada", subtitle: "Trabalho especializado" },
];

export default function HomePage() {
  return (
    <div className="min-h-screen text-slate-900 bg-white">
      {/* WhatsApp Floating Button */}
      <a
        href="https://wa.me/351931632622"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 inline-flex items-center justify-center w-14 h-14 rounded-full bg-green-500 text-white shadow-lg hover:bg-green-600 transition-all hover:scale-110"
        aria-label="Contactar via WhatsApp"
      >
        <MessageCircle className="w-7 h-7" />
      </a>

      {/* HERO */}
      <section className="relative overflow-hidden bg-gradient-to-br from-cyan-50 via-cyan-100 to-cyan-50">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,_rgba(34,211,238,0.3),_transparent_40%),radial-gradient(circle_at_bottom_right,_rgba(6,182,212,0.25),_transparent_35%)]" />
        <div className="relative mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
          <div className="grid gap-12 lg:grid-cols-2 lg:gap-12 items-center">
            {/* Left Content */}
            <div className="flex flex-col justify-center">
              <div className="mb-8 inline-flex w-fit items-center gap-3 rounded-full border border-cyan-200 bg-white px-4 py-2.5 text-sm font-medium text-cyan-600 backdrop-blur-sm shadow-sm">
                <span className="h-2.5 w-2.5 rounded-full" style={{backgroundColor: "#00BCD4"}} />
                Líderes em satisfação no Fixando — 163 avaliações 5★
              </div>
              
              <h1 className="text-6xl font-black leading-tight tracking-tight text-slate-950 sm:text-7xl lg:text-7xl">
                Recolha e limpeza
                <span className="block" style={{color: "#00BCD4"}}>rápida, moderna e</span>
                <span className="block" style={{color: "#00BCD4"}}>sem stress.</span>
              </h1>
              
              <p className="mt-8 text-base leading-7 text-slate-600">
                Entulho, móveis velhos, limpeza pós-obra e apoio em mudanças com atendimento rápido, orçamento claro e execução profissional em Lisboa, Margem Sul e Setúbal.
              </p>

              {/* CTA Buttons */}
              <div className="mt-10 flex flex-col gap-3 sm:flex-row sm:items-center">
                <Link
                  href="/simulador"
                  className="inline-flex items-center justify-center rounded-full px-8 py-3 text-base font-semibold text-white shadow-lg transition hover:shadow-xl"
                  style={{backgroundColor: "#00BCD4"}}
                >
                  Simular Orçamento
                </Link>
                <Link
                  href="/trabalhos"
                  className="inline-flex items-center justify-center rounded-full bg-white px-8 py-3 text-base font-semibold transition hover:bg-cyan-50"
                  style={{border: "2px solid #00BCD4", color: "#00BCD4"}}
                >
                  Ver Trabalhos Reais
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </div>

              {/* Stats */}
              <div className="mt-12 grid gap-4 sm:grid-cols-3">
                {stats.map((stat) => (
                  <div key={stat.label} className="rounded-xl border border-cyan-100 bg-white/80 p-4 shadow-sm backdrop-blur-sm">
                    <div className="text-2xl font-bold text-slate-950">{stat.value}</div>
                    <div className="mt-1 text-xs text-slate-600 font-medium">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Image - Carousel */}
            <div className="relative flex items-center justify-center w-full h-full lg:min-h-[600px] bg-gradient-to-br from-cyan-50 to-cyan-100">
              <div className="w-full h-full lg:min-h-[600px] rounded-3xl overflow-hidden shadow-2xl shadow-cyan-200 border border-cyan-100 bg-white">
                <ImageCarousel
                  images={workImages}
                  autoPlay={true}
                  autoPlayInterval={5000}
                  showIndicators={true}
                  showArrows={true}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SERVIÇOS */}
      <section id="servicos" className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="mb-16 flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-wider" style={{color: "#00BCD4"}}>Serviços principais</p>
            <h2 className="mt-4 text-4xl font-bold tracking-tight text-slate-950 sm:text-5xl">
              Menos ruído, mais clareza sobre o que a CLYON resolve.
            </h2>
          </div>
          <p className="max-w-sm text-slate-600">
            Serviços organizados em blocos fortes, fáceis de ler e comparar — com orçamento imediato.
          </p>
        </div>
        
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {services.map((service) => (
            <Link key={service.name} href="/simulador">
              <div className="group rounded-3xl border border-cyan-100 bg-white overflow-hidden shadow-md transition hover:shadow-xl hover:shadow-cyan-200/50 hover:-translate-y-2 cursor-pointer h-full">
                <div className="relative h-48 bg-gradient-to-br from-cyan-50 to-cyan-100 flex items-center justify-center overflow-hidden">
                  <div className="text-cyan-500 group-hover:scale-110 transition-transform duration-300">
                    <service.icon className="w-24 h-24" strokeWidth={1.2} />
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-slate-950">{service.name}</h3>
                  <p className="mt-3 text-sm leading-6 text-slate-600">{service.description}</p>
                  <span className="mt-4 inline-flex items-center text-sm font-semibold text-cyan-600 group-hover:text-cyan-700">
                    Simular orçamento <ChevronRight className="ml-1 h-4 w-4" />
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* COMO FUNCIONA */}
      <section className="relative overflow-hidden bg-gradient-to-b from-cyan-50 to-white">
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
          <div className="mb-16 text-center">
            <p className="text-sm font-semibold uppercase tracking-wider" style={{color: "#00BCD4"}}>Como funciona</p>
            <h2 className="mt-4 text-4xl font-bold tracking-tight text-slate-950 sm:text-5xl">
              Simples. Rápido. Sem stress.
            </h2>
            <p className="mt-6 mx-auto max-w-2xl text-lg text-slate-600">
              Do primeiro contacto à recolha final — tudo resolvido em 3 passos.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-3">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-24 left-full w-full h-1 bg-gradient-to-r from-cyan-200 to-transparent" />
                )}
                <div className="relative">
                  <div className={`inline-flex h-16 w-16 items-center justify-center rounded-full ${step.color} text-white font-bold text-2xl shadow-lg ${step.shadow}`}>
                    {index + 1}
                  </div>
                  <div className="mt-6">
                    <div className={`text-sm font-semibold ${step.durationColor}`}>
                      {step.duration}
                    </div>
                    <h3 className="mt-3 text-xl font-bold text-slate-950">{step.title}</h3>
                    <p className="mt-3 text-slate-600">{step.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 text-center">
            <Link
              href="/simulador"
              className="inline-flex items-center justify-center rounded-full bg-cyan-500 px-8 py-4 text-base font-semibold text-white shadow-lg shadow-cyan-200 transition hover:bg-cyan-600"
            >
              Simular orçamento agora
            </Link>
            <p className="mt-4 text-sm text-slate-500">Grátis e sem compromisso · Resposta em menos de 11 minutos</p>
          </div>
        </div>
      </section>

      {/* TRABALHOS */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="mb-16 text-center">
          <h2 className="text-4xl font-bold tracking-tight text-slate-950 sm:text-5xl">
            Veja o que fazemos no terreno.
          </h2>
          <p className="mt-6 mx-auto max-w-2xl text-lg text-slate-600">
            Fotos reais dos nossos trabalhos — entulho, móveis, limpezas e mudanças em Lisboa, Margem Sul e Setúbal.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {workImages.map((image, index) => (
            <Link key={index} href="/trabalhos">
              <div className="group relative overflow-hidden rounded-3xl h-64 cursor-pointer shadow-md hover:shadow-xl transition">
                <img
                  src={image.url}
                  alt={image.alt}
                  className="h-full w-full object-cover transition group-hover:scale-110 duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition duration-300 flex flex-col justify-end p-6">
                  <h3 className="text-xl font-bold text-white">{image.title}</h3>
                  <p className="text-cyan-200 text-sm">{image.subtitle}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Link
            href="/trabalhos"
            className="inline-flex items-center text-lg font-semibold transition"
            style={{color: "#00BCD4"}}
          >
            Ver todos os trabalhos <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>

      {/* COBERTURA */}
      <section className="bg-gradient-to-b from-white to-cyan-50">
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
          <div className="mb-16 text-center">
            <h2 className="text-4xl font-bold tracking-tight text-slate-950 sm:text-5xl">
              Cobertura
            </h2>
            <p className="mt-6 text-lg text-slate-600">
              Lisboa · Margem Sul · Setúbal
            </p>
          </div>

          <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-5">
            {["Lisboa", "Benfica", "Lumiar", "Olivais", "Alvalade", "Almada", "Seixal", "Barreiro", "Moita", "Setúbal", "Palmela", "Sesimbra"].map((city) => (
              <div key={city} className="rounded-xl border border-cyan-100 bg-white p-4 text-center font-medium text-slate-700 hover:bg-cyan-50 transition shadow-sm hover:shadow-md">
                {city}
              </div>
            ))}
          </div>

          <div className="mt-12 rounded-3xl border border-cyan-200 bg-cyan-50 p-8 text-center shadow-md">
            <p className="text-slate-700">Não encontrou a sua zona?</p>
            <Link
              href="https://wa.me/351"
              className="mt-4 inline-flex items-center font-semibold transition"
              style={{color: "#00BCD4"}}
            >
              Confirme disponibilidade por WhatsApp <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* PROVA SOCIAL */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="mb-16 text-center">
          <h2 className="text-4xl font-bold tracking-tight text-slate-950 sm:text-5xl">
            163 avaliações de clientes reais.
          </h2>
          <p className="mt-6 text-lg text-slate-600">
            Avaliação média 5.0 ★★★★★ no Fixando e Google
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="rounded-3xl border border-cyan-100 bg-white p-8 shadow-md hover:shadow-xl hover:shadow-cyan-200/50 transition">
              <div className="flex items-center gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-slate-700 leading-7">{testimonial.text}</p>
              <div className="mt-6 flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-cyan-100 flex items-center justify-center font-bold text-cyan-600">
                  {testimonial.name.charAt(0)}
                </div>
                <div>
                  <p className="font-semibold text-slate-950">{testimonial.name}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Link
            href="https://www.fixando.pt"
            className="inline-flex items-center text-lg font-semibold transition"
            style={{color: "#00BCD4"}}
          >
            Ver todas as avaliações <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>

      {/* DIFERENCIAIS */}
      <section className="bg-gradient-to-b from-cyan-50 to-white">
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
          <div className="mb-16 text-center">
            <h2 className="text-4xl font-bold tracking-tight text-slate-950 sm:text-5xl">
              Por que escolher a CLYON?
            </h2>
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {whyUs.map((item, index) => (
              <div key={index} className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-cyan-100 shadow-sm">
                    <CheckCircle2 className="h-6 w-6 text-cyan-600" />
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-slate-950">{item.title}</h3>
                  <p className="mt-2 text-slate-600">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="bg-gradient-to-r from-cyan-500 to-cyan-600 text-white">
        <div className="mx-auto max-w-4xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28 text-center">
          <h2 className="text-4xl font-bold tracking-tight sm:text-5xl">
            Livre-se do entulho, dos móveis velhos e da bagunça — hoje mesmo.
          </h2>
          <p className="mt-8 text-lg text-cyan-100">
            Orçamento gratuito em 11 minutos. Sem compromisso, sem custos ocultos. Recolha no mesmo dia em Lisboa, Margem Sul e Setúbal.
          </p>
          <div className="mt-8 rounded-lg border border-white/30 bg-white/10 p-4 backdrop-blur-sm">
            <p className="text-sm text-white">
              ⚠️ <strong>Não descarte monos na via pública.</strong> É ilegal e prejudica o ambiente. Agende a recolha connosco — fazemos o transporte de forma legal e certificada.
            </p>
          </div>
          <div className="mt-10 flex flex-col gap-4 sm:flex-row sm:justify-center">
            <Link
              href="/simulador"
              className="inline-flex items-center justify-center rounded-full px-8 py-4 text-base font-semibold shadow-lg transition hover:shadow-xl"
              style={{backgroundColor: "white", color: "#00BCD4"}}
            >
              Simular Orçamento
            </Link>
            <Link
              href="https://wa.me/351"
              className="inline-flex items-center justify-center rounded-full px-8 py-4 text-base font-semibold text-white transition hover:bg-white/10"
              style={{border: "2px solid white"}}
            >
              Falar no WhatsApp
              <MessageCircle className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
